
<!-- Data Tabled Css  -->
<link rel="stylesheet" href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.14/dist/sweetalert2.all.min.js"></script>
    <!-- Fav  -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.0/jquery.fancybox.min.css" rel="stylesheet" />
    <!-- Style for Dialog Box -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.0/jquery.fancybox.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.0/jquery.fancybox.min.css">
  
<!-- font awesome icon -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  
  


<link rel="icon" href="https://crsorgi-gov.co/web/images//favicon111.ico">
    <script>
        window.location.href = '../login.php';
    </script>
<!DOCTYPE html>
<html lang="en">

<head>
    

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
   <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
</head>


    

        

       
        

           
        </aside><!DOCTYPE html>
<!-- saved from url=(0021)https://uidai.gov.in/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<base href="/">--><base href=".">

	<!-- CSS only -->
	<link href="./State_files/bootstrap5_1_3.min.css" rel="stylesheet" type="text/css">
	<link href="./State_files/fonts-local_roboto.css" rel="stylesheet" type="text/css">
	<link href="./State_files/langpage_style.css" rel="stylesheet" type="text/css">
    <title>State Selection - Civil Registration System</title>
	<link rel="shortcut icon" href="https://crsorgi.gov.in/web/images//favicon.ico" type="image/vnd.microsoft.icon">

</head>
<body>
	
	
	<div class="back col-sm-12 container-fluid">
	<center>
		<div class="btn-div col-sm-10" role="group" aria-label="Basic example">
			
			<div class="m-t"><p class="text-responsive " style="
    padding-top: 160px;
">Select your State to Enter the Website</p><p class="text-responsive ">वेबसाइट में प्रवेश करने के लिए अपने राज्य का चयन करें</p></div>
		 <div class="form-group col-md-6">
                                <label for="state">State<span class="text-danger"></span></label>
                                <select onchange="location.href = this.value;"class="form-control" id="state" name="state" required="">
                                <option value="">Select State</option>
                 <option url="index_all.php" value="index_all.php">Andhra Pradesh</option>
                  <option url="index_all.php" value="index_all.php">Arunachal Pradesh</option>
                   <option url="index_all.php" value="index_all.php">Assam</option>
                    <option url="index_bh.php" value="index_bh.php">Bihar</option>
                     <option url="index_all.php" value="index_all.php">Chhattisgarh</option>
                      <option url="index_all.php" value="index_all.php">Goa</option>
                       <option url="index_all.php" value="index_all.php">Gujarat</option>
                        <option url="index_all.php" value="index_all.php">Haryana</option>
                         <option url="index_all.php" value="index_all.php">Himachal Pradesh</option>
                          <option url="index_jh.php" value="index_jh.php">Jharkhand</option>
                           <option url="index_all.php" value="index_all.php">Karnataka</option>
                            <option url="index_all.php" value="index_all.php">Kerala</option>
                             <option url="index_mp.php" value="index_mp.php">Madhya Pradesh</option>
                              <option url="index_all.php" value="index_all.php">Maharashtra</option>
                               <option url="index_all.php" value="index_all.php">Manipur</option>
                                <option url="index_all.php" value="index_all.php">Meghalaya</option>
                                 <option url="index_all.php" value="index_all.php">Mizoram</option>
                                  <option url="index_all.php" value="index_all.php">Nagaland</option>
                                   <option url="index_all.php" value="index_all.php">Odisha</option>
                                    <option url="index_all.php" value="index_all.php">Punjab</option>
                                     <option url="index_all.php" value="index_all.php">Rajasthan</option>
                                      <option url="index_all.php" value="index_all.php">Sikkim</option>
                                       <option url="index_all.php" value="index_all.php">Tamil Nadu</option>
                                        <option url="index_all.php" value="index_all.php">Telangana</option>
                                         <option url="index_all.php" value="index_all.php">Tripura</option>
                                          <option url="index_all.php" value="index_up.php">Uttar Pradesh</option>
                                           <option url="index_all.php" value="index_all.php">Uttarakhand</option>
                                            <option url="index_all.php" value="index_wb.php">West Bengal</option>
                                             <option url="index_all.php" value="index_all.php">Andaman and Nicobar Islands</option>
                                              <option url="index_all.php" value="index_all.php">Chandigarh</option>
                                               <option url="index_all.php" value="index_all.php">Dadra & Nagar Haveli and Daman & Diu</option>
                                                <option url="index_all.php" value="index_all.php">Delhi</option>
                                                 <option url="index_all.php" value="index_all.php">Jammu and Kashmir</option>
                                                  <option url="index_all.php" value="index_all.php">Lakshadweep</option>
                                                   <option url="index_all.php" value="index_all.php">Puducherry</option>
                                       <option url="index_all.php" value="index_all.php">Ladakh</option>
                                        </select>
        </div>
        
	</center>
	<div align="center" valign="middle" class="footer-content-strip">
            The Registrar General &amp; Census Commissioner, India © 2023    </div>
	</div>

</body></html>